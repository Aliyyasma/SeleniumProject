﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace CsharpSeleniumFramework.Utilities
{
    public class jsonReader
    {
        public string extractData(string tokenName)
        {
            var myJsonString = File.ReadAllText("utilities/TestData.json");
            var jsonObject = JToken.Parse(myJsonString);
            return jsonObject.SelectToken(tokenName).Value<string>();
        }

    }
}
