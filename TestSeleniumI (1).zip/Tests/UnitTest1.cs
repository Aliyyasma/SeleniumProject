using CsharpSeleniumFramework.pageObjects;
using CsharpSeleniumFramework.Utilities;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WebDriverManager.DriverConfigs.Impl;
using WebDriverManager.Helpers;


namespace CsharpSeleniumFramework
{
    public class UnitTest1 : Base
    {
        
        [Test, TestCaseSource("AddTestDataConfig"),Category("regression")]
        [Parallelizable(ParallelScope.All)]
        //[TestCase ("rahulshettyacademy", "learning")]
        //[TestCase ("rahulshetty", "learning")]
        public void E2EFlow(String username, String password)
        {
            String[] actualProducts = new string[2];
            String[] expectedProducts = { "iphone X", "Blackberry" };

            

            LoginPage loginPage = new LoginPage(getDriver());
            ProductsPage productsPage = loginPage.validLogin(username, password);
            productsPage.waitForPageDisplay();
            
            IList<IWebElement> products = productsPage.getCards();
            foreach (IWebElement product in products)
            {
                if (expectedProducts.Contains(product.FindElement(productsPage.getCardTitle()).Text))
                {
                    product.FindElement(productsPage.addToCartButton()).Click();
                }

            }
            CheckoutPage checkoutPage = productsPage.checkout();
            IList<IWebElement> checkoutCards = checkoutPage.getCards();

            for (int i = 0; i < checkoutCards.Count; i++)
            {
                actualProducts[i] = checkoutCards[i].Text;
            }
            Assert.AreEqual(expectedProducts, actualProducts);
            checkoutPage.clickSuccessButton();


            MessagePage messagePage = new MessagePage(getDriver());
            String confirmText = messagePage.fillCountryBox();


            StringAssert.Contains("Success", confirmText);
        }

        public static IEnumerable<TestCaseData> AddTestDataConfig()
        {
            yield return new TestCaseData(getDataPasser().extractData("username"), getDataPasser().extractData("password"));
            yield return new TestCaseData(getDataPasser().extractData("username_wrong"), getDataPasser().extractData("password_wrong"));

        }
    }
}
