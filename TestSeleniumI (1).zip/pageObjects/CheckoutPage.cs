﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpSeleniumFramework.pageObjects
{
    public class CheckoutPage
    {
        IWebDriver driver;
        public CheckoutPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.CssSelector, Using = "h4 a")]
        private IList<IWebElement> checkoutCards;

       

        [FindsBy(How = How.CssSelector, Using = ".btn-success")]
        private IWebElement successButton;

        
        

        public IList<IWebElement> getCards()
        {
            return checkoutCards;
        }

        public void clickSuccessButton()
        {
            successButton.Click();
            
        }
    }
    //driver.FindElements(By.CssSelector("h4 a")
    

}
