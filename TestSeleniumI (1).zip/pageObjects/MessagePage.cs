﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using OpenQA.Selenium.Support.UI;

namespace CsharpSeleniumFramework.pageObjects
{
    public class MessagePage
    {
        IWebDriver driver;
        public MessagePage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.LinkText, Using = "India")]
        private IWebElement indiaOption;

        [FindsBy(How = How.CssSelector, Using = "label[for*='checkbox2'")]
        private IWebElement tncBox;

        [FindsBy(How = How.Id, Using = "country")]
        private IWebElement countryBox;

        [FindsBy(How = How.XPath, Using = "//input[@value='Purchase']")]
        private IWebElement purchaseButton;

        [FindsBy(How = How.CssSelector, Using = ".alert-success")]
        private IWebElement alertMsg;

        

        public String fillCountryBox()
        {
            countryBox.SendKeys("ind");
            indiaOption.Click();
            tncBox.Click();
            purchaseButton.Click();
            return alertMsg.Text;
        }

        public void waitForOptionsDisplay()
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(8));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible((By.LinkText("India"))));
        }
    }
}
