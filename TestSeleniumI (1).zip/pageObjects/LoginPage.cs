﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace CsharpSeleniumFramework.pageObjects
{
    public class LoginPage
    {
        private IWebDriver driver; 
        //constructor
        public LoginPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }
        //driver.FindElement(By.Id("username"))
        //By.Id("username")

        //driver.FindElement(By.Name("password")).SendKeys("learning");
        //driver.FindElement(By.Id("signInBtn")).Click();

        //page object factory
        //FindElement(By.Id("username")
        [FindsBy(How = How.Id, Using = "username")]
        private IWebElement username;

        [FindsBy(How = How.Name, Using = "password")]
        private IWebElement password;

        [FindsBy(How = How.Id, Using = "signInBtn")]
        private IWebElement signIn;

        public ProductsPage validLogin(string user, string pass)
        {
            username.SendKeys(user);
            password.SendKeys(pass);
            signIn.Click();

            return new ProductsPage(driver);
        }
        //public IWebElement getUserName()
        //{
          //  return username;
        //}
    }
}
